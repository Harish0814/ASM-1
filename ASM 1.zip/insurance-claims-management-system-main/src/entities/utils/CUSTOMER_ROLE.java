package entities.utils;

public enum CUSTOMER_ROLE {
    POLICYHOLDER("POLICYHOLDER"),INSUREDPERSON("INSUREDPERSON");

    private final String text;

    CUSTOMER_ROLE(final String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return this.text;
    }
}
