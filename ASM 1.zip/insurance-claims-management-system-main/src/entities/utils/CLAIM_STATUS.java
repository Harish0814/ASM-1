package entities.utils;

public enum CLAIM_STATUS {
    NEW("NEW"),PROCESSING("PROCESSING"),DONE("DONE");

    private final String text;

    CLAIM_STATUS(final String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return text;
    }
}
