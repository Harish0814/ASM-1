package entities.utils;

public interface Formats {
}
