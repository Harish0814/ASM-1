package entities;

import entities.customer.CardHolder;
import entities.utils.CLAIM_STATUS;

import java.util.Date;


public class Claim {
    private int id;
    private Date claimDate;
    private String insuredPersonId;
    private Date examDate;

    // with the format ClaimId_CardNumber_DocumentName.pdf
    private String listOfDocuments;

    private String cardNumber;
    private CLAIM_STATUS claimStatus;
    private int claimAmount;
    // Receiver Banking Info (Bank – Name – Number)
    private String bankingInfo;

    public Claim(){

    };
    public Claim(int id, Date claimDate, String insuredPersonId, Date examDate, String listOfDocuments, CLAIM_STATUS claimStatus, int claimAmount, String bankingInfo,String cardNumber) {
        this.id = id;
        this.claimDate = claimDate;
        this.insuredPersonId = insuredPersonId;
        this.examDate = examDate;
        this.listOfDocuments = listOfDocuments;
        this.claimStatus = claimStatus;
        this.claimAmount = claimAmount;
        this.bankingInfo = bankingInfo;
        this.cardNumber = cardNumber;
    }



    public Date getClaimDate() {
        return claimDate;
    }

    public void setClaimDate(Date claimDate) {
        this.claimDate = claimDate;
    }

    public Date getExamDate() {
        return examDate;
    }

    public void setExamDate(Date examDate) {
        this.examDate = examDate;
    }



    public CLAIM_STATUS getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(CLAIM_STATUS claimStatus) {
        this.claimStatus = claimStatus;
    }

    public int getClaimAmount() {
        return claimAmount;
    }

    public String getInsuredPersonId() {
        return insuredPersonId;
    }

    public void setInsuredPersonId(String insuredPersonId) {
        this.insuredPersonId = insuredPersonId;
    }

    public void setClaimAmount(int claimAmount) {
        this.claimAmount = claimAmount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getListOfDocuments() {
        return listOfDocuments;
    }

    public void setListOfDocuments(String listOfDocuments) {
        this.listOfDocuments = listOfDocuments;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getBankingInfo() {
        return bankingInfo;
    }

    public void setBankingInfo(String bankingInfo) {
        this.bankingInfo = bankingInfo;
    }
}
