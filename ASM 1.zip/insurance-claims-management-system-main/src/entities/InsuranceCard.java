package entities;

public class InsuranceCard {
    private int cardNumber;
    private int cardHolderID;
    private int policyHolderID;


    public InsuranceCard(int cardNumber){
        this.cardNumber = cardNumber;
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(int cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getCardHolderID() {
        return cardHolderID;
    }

    public void setCardHolderID(int cardHolderID) {
        this.cardHolderID = cardHolderID;
    }

    public int getPolicyHolderID() {
        return policyHolderID;
    }

    public void setPolicyHolderID(int policyHolderID) {
        this.policyHolderID = policyHolderID;
    }
    @Override
    public String toString(){
        return "Insurance card id: " + cardNumber ;
    }
}
