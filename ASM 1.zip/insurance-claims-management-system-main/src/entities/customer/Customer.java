package entities.customer;

import entities.Claim;
import entities.InsuranceCard;
import entities.utils.CUSTOMER_ROLE;
import entities.utils.Formats;

import java.util.ArrayList;
import java.util.List;

public abstract class Customer implements Formats {
    private int id;
    private String fullName;
    private static CUSTOMER_ROLE customerRole;
    private String role;
    // insurance card not exist if null
    private String insuranceCardNumber;

    private ArrayList<String> claimsId;

    public Customer() {
    }

    ;

    protected Customer(int id, String fullName) {
        this.id = id;
        this.fullName = fullName;
    }

    public CUSTOMER_ROLE getCustomerRole() {
        return customerRole;
    }

    public void setCustomerRole(CUSTOMER_ROLE customerRole) {
        Customer.customerRole = customerRole;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getInsuranceCardNumber() {
        return insuranceCardNumber;
    }

    public void setInsuranceCardNumber(String insuranceCardNumber) {
        this.insuranceCardNumber = insuranceCardNumber;
    }
    @Override
    public String toString() {
        return "Name: " + fullName + ", ID: " + id + ", role: " + role;
    }
}
