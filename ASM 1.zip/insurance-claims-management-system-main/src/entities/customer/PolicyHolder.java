package entities.customer;

import entities.Claim;
import entities.InsuranceCard;
import entities.utils.CUSTOMER_ROLE;

import java.util.ArrayList;
import java.util.List;

public class PolicyHolder extends Customer{
    private ArrayList<String> cardHolderListId;
    public PolicyHolder(int id, String fullName){
        super(id,fullName);
        super.setRole(CUSTOMER_ROLE.POLICYHOLDER.toString());
    }

    public void setCardHolderList(ArrayList<String> cardHolderListId) {
        this.cardHolderListId = cardHolderListId;
    }

    public ArrayList<String> getCardHolderList() {
        return cardHolderListId;
    }
}
