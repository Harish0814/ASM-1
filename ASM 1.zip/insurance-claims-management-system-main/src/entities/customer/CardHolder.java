package entities.customer;

import entities.Claim;
import entities.InsuranceCard;
import entities.utils.CUSTOMER_ROLE;

import java.util.List;

public class CardHolder extends Customer {
    public CardHolder(){
        super.setRole(CUSTOMER_ROLE.INSUREDPERSON.toString());
    };
    public CardHolder(int id, String fullName){
        super(id,fullName);
        // set role to cardHolder
        super.setRole(CUSTOMER_ROLE.INSUREDPERSON.toString());
        // handle insuranceCard
    }


}
