package repositories;


import entities.customer.CardHolder;
import entities.customer.Customer;


import java.io.*;
import java.util.List;


public class CustomerRep {

    private final String path = "../data/customerData.txt";
    private static BufferedReader reader;
    private List<Customer> customers;

    public CustomerRep() {
        this.reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(path)));
        findCustomers();
    }

    ;

    public void findCustomers() {
        List<String> customers = reader.lines().toList();
        for (String e : customers) {
            String[] customerDetails = e.split(",", -1);
            Customer customer = new CardHolder();


        }
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
}
