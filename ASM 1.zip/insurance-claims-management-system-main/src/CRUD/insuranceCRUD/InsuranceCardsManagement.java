package CRUD.insuranceCRUD;


import entities.InsuranceCard;
import entities.customer.PolicyHolder;

import java.util.ArrayList;

public class InsuranceCardsManagement implements insuranceCardsCRUD {
    private ArrayList<InsuranceCard> insuranceCards;

    public InsuranceCardsManagement(ArrayList<InsuranceCard> insuranceCards){
        this.insuranceCards = insuranceCards;
    }

    public ArrayList<InsuranceCard> getInsuranceCards() {
        return insuranceCards;
    }

    public void setInsuranceCards(ArrayList<InsuranceCard> insuranceCards) {
        this.insuranceCards = insuranceCards;
    }

    public boolean insuranceCardExist(InsuranceCard insuranceCard) {
        // check if insuranceCard exist
        for (InsuranceCard i : insuranceCards) {
            if (i.getCardNumber() == insuranceCard.getCardNumber()) {
                return true;
            }
        }
        return false;

    }
    @Override
    public void addInsuranceCard(InsuranceCard insuranceCard) {
    // if not exist add
        if(insuranceCardExist(insuranceCard)){
            System.out.println("insurance card existed");
        }else{
            // add to system
            insuranceCards.add(insuranceCard);
        }
    }

    @Override
    public InsuranceCard getInsuranceCard(InsuranceCard insuranceCard) {
        // if exist get
        if(!insuranceCardExist(insuranceCard)){
            System.out.println("insuranceCard not existed");
            return null;
        }else{
            // get insuranceCard
            return insuranceCard;
        }
    }


    @Override
    public void deleteInsuranceCard(InsuranceCard insuranceCard) {
        // if exist delete
        if(!insuranceCardExist(insuranceCard)){
            System.out.println("insuranceCard not existed");
        }else{
            // delete insuranceCard
            insuranceCards.remove(insuranceCard);
        }
    }

    @Override
    public void updateInsuranceCard(InsuranceCard insuranceCard, InsuranceCard newinsuranceCard) {
        // if exist update
        if(!insuranceCardExist(insuranceCard)){
            System.out.println("insuranceCard not existed");
        }else{
            // delete old insuranceCard
            insuranceCards.remove(insuranceCard);
            // add new insuranceCard
            insuranceCards.add(newinsuranceCard);
        }
    }
    @Override
    public String toString() {
        StringBuilder info = new StringBuilder();

        for (InsuranceCard c : insuranceCards) {
            info.append(c.toString()).append("\n");
        }

        return info.toString();
    }
}
