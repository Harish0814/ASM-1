package CRUD.insuranceCRUD;

import entities.InsuranceCard;

public interface insuranceCardsCRUD {

        public void addInsuranceCard(InsuranceCard insuranceCard);
        public InsuranceCard getInsuranceCard(InsuranceCard insuranceCard);
        public void deleteInsuranceCard(InsuranceCard insuranceCard);
        public void updateInsuranceCard(InsuranceCard insuranceCard,InsuranceCard newinsuranceCard);

}
