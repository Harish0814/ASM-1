package CRUD.customerCRUD;

import entities.customer.Customer;
import entities.customer.PolicyHolder;

import java.util.ArrayList;

public class PolicyHoldersManagement implements CustomerCRUD {
    private ArrayList<PolicyHolder> policyHolders;

    public PolicyHoldersManagement() {
    }

    ;

    public PolicyHoldersManagement(ArrayList<PolicyHolder> policyHolders) {
        this.policyHolders = policyHolders;
    }

    public boolean policyHolderExist(PolicyHolder policyHolder) {
        // check if policyholder exist
        for (PolicyHolder p : policyHolders) {
            if (p.getId() == policyHolder.getId()) {
                return true;
            }
        }
        return false;

    }

    @Override
    public void addCustomer(Customer customer) {
        // if exist
        if (policyHolderExist((PolicyHolder) customer)) {
            System.out.println("Policy holder already exist");
        } else {
            policyHolders.add((PolicyHolder) customer);
        }

    }

    @Override
    public Customer getCustomer(Customer customer) {
        // if exist get
        if (!policyHolderExist((PolicyHolder) customer)) {
            System.out.println("Policy holder not exist");
            return null;
        } else {
            // get customer
            return customer;

        }
    }

    @Override
    public void deleteCustomer(Customer customer) {
        // if exist delete
        if (!policyHolderExist((PolicyHolder) customer)) {
            System.out.println("Policy holder do not exist");
        } else {
            // delete
            System.out.println("PolicyHolder deleted");
            policyHolders.remove((PolicyHolder) customer);
        }

    }

    @Override
    public void updateCustomer(Customer customer, Customer newCustomer) {
        // if exist update
        if (!policyHolderExist((PolicyHolder) customer)) {
            System.out.println("PolicyHolder dot not exist");
        } else {
            // delete old customer
            policyHolders.remove((PolicyHolder) customer);
            // add updated customer
            policyHolders.add((PolicyHolder) newCustomer);
        }
    }
    @Override
    public String toString() {
        StringBuilder info = new StringBuilder();

        for (PolicyHolder p : policyHolders) {
           info.append(p.toString()).append("\n");
        }

        return info.toString();
    }

    public ArrayList<PolicyHolder> getPolicyHolders() {
        return policyHolders;
    }

    public void setPolicyHolders(ArrayList<PolicyHolder> policyHolders) {
        this.policyHolders = policyHolders;
    }


}
