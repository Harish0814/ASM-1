package CRUD.customerCRUD;

import entities.customer.CardHolder;
import entities.customer.Customer;
import entities.customer.PolicyHolder;

import java.util.ArrayList;

public class CardHoldersManagement implements CustomerCRUD {
    private ArrayList<CardHolder> cardHolders;

    public CardHoldersManagement() {
    }

    ;

    public CardHoldersManagement(ArrayList<CardHolder> cardHolders) {
        this.cardHolders = cardHolders;
    }

    public boolean cardHolderExist(Customer cardHolder) {
        for (CardHolder c : cardHolders) {
            if (c.getId() == cardHolder.getId()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void addCustomer(Customer customer) {
        // add cardholder if cardholder not exist
        if (cardHolderExist(customer)) {
            System.out.println("Cardholder already exist");
        } else {
            cardHolders.add((CardHolder) customer);
        }

    }

    @Override
    public Customer getCustomer(Customer customer) {
        // get cardholder if exist
        if (!cardHolderExist(customer)) {
            System.out.println("Cardholder dot not exist");
            return null;
        } else {
            return customer;
        }
    }

    @Override
    public void deleteCustomer(Customer customer) {
        // if exist delete
        if (!cardHolderExist(customer)) {
            System.out.println("Cardholder dot not exist");
        } else {
            // delete
            System.out.println("Cardholder deleted");
            cardHolders.remove((CardHolder) customer);
        }
    }

    @Override
    public void updateCustomer(Customer customer, Customer newCustomer) {
        if (!cardHolderExist(customer)) {
            System.out.println("Cardholder dot not exist");
        } else {
            // delete old customer
            cardHolders.remove((CardHolder) customer);
            // add updated customer
            cardHolders.add((CardHolder) newCustomer);
        }
    }

    @Override
    public String toString() {
        StringBuilder info = new StringBuilder();

        for (CardHolder c : cardHolders) {
            info.append(c.toString()).append("\n");
        }

        return info.toString();
    }


    public ArrayList<CardHolder> getCardHolders() {
        return cardHolders;
    }

    public void setCardHolders(ArrayList<CardHolder> cardHolders) {
        this.cardHolders = cardHolders;
    }
}
