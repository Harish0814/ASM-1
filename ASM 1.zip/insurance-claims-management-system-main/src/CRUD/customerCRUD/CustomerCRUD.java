package CRUD.customerCRUD;

import entities.customer.Customer;

public interface CustomerCRUD {
    public void addCustomer(Customer customer);
    public Customer getCustomer(Customer customer);
    public void deleteCustomer(Customer customer);
    public void updateCustomer(Customer customer,Customer newCustomer);

}
