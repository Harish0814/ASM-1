package CRUD.claimCRUD;

import entities.Claim;

public interface claimsCRUD {
    public void addClaim(Claim claim);
    public Claim getClaim(Claim claim);
    public void deleteClaim(Claim claim);
    public void updateClaim(Claim claim,Claim newClaim);
}
