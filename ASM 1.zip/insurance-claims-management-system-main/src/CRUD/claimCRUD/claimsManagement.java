package CRUD.claimCRUD;

import entities.Claim;
import entities.customer.PolicyHolder;

import java.util.ArrayList;

public class claimsManagement implements claimsCRUD {

    private ArrayList<Claim> claims;

    public claimsManagement(ArrayList<Claim> claims){
        this.claims = claims;
    }

    public ArrayList<Claim> getClaims() {
        return claims;
    }

    public void setClaims(ArrayList<Claim> claims) {
        this.claims = claims;
    }

    public boolean claimExist(Claim claim) {
        // check if claim exist
        for (Claim c : claims) {
            if (c.getId() == claim.getId()) {
                return true;
            }
        }
        return false;

    }
    @Override
    public void addClaim(Claim claim) {
        if(claimExist(claim)){
            System.out.println("Claim already exist");
        }else {
            // add claim if not exist
            claims.add(claim);
        }

    }

    @Override
    public Claim getClaim(Claim claim) {
        if(!claimExist(claim)){
            System.out.println("Claim does not exist");
            return null;
        }else {
            // return claim
            for (Claim c : claims) {
                if (c.getId() == claim.getId()) {
                    return c;
                }
            }
            return null;
        }
    }

    @Override
    public void deleteClaim(Claim claim) {

    }

    @Override
    public void updateClaim(Claim claim, Claim newClaim) {

    }
}
