import CRUD.customerCRUD.CardHoldersManagement;
import CRUD.customerCRUD.PolicyHoldersManagement;

public class ClaimProcessManager  {
    private CardHoldersManagement cardHoldersManagement;
    private PolicyHoldersManagement policyHoldersManagement;

    public ClaimProcessManager(){};

    public ClaimProcessManager(CardHoldersManagement cardHoldersManagement, PolicyHoldersManagement policyHoldersManagement) {
        this.cardHoldersManagement = cardHoldersManagement;
        this.policyHoldersManagement = policyHoldersManagement;
    }

    public CardHoldersManagement getCardHoldersManagement() {
        return cardHoldersManagement;
    }

    public void setCardHoldersManagement(CardHoldersManagement cardHoldersManagement) {
        this.cardHoldersManagement = cardHoldersManagement;
    }

    public PolicyHoldersManagement getPolicyHoldersManagement() {
        return policyHoldersManagement;
    }

    public void setPolicyHoldersManagement(PolicyHoldersManagement policyHoldersManagement) {
        this.policyHoldersManagement = policyHoldersManagement;
    }
}
