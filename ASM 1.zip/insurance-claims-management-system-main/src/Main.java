import CRUD.customerCRUD.CardHoldersManagement;
import CRUD.customerCRUD.PolicyHoldersManagement;
import CRUD.insuranceCRUD.InsuranceCardsManagement;
import entities.Claim;
import entities.InsuranceCard;
import entities.customer.CardHolder;
import entities.customer.Customer;
import entities.customer.PolicyHolder;
import repositories.CustomerRep;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        ArrayList<PolicyHolder> policyHolders = new ArrayList<>();
        ArrayList<CardHolder> cardholders = new ArrayList<>();
        ArrayList<InsuranceCard> insuranceCards = new ArrayList<>();
        //test
//        PolicyHolder policyHolder1 = new PolicyHolder(1,"dat");
//        PolicyHolder policyHolder2 = new PolicyHolder(2,"nam");
//        PolicyHolder policyHolder3 = new PolicyHolder(3,"vu");
//        PolicyHolder policyHolder4 = new PolicyHolder(4,"vu");
//        policyHolders.add(policyHolder1);
//        policyHolders.add(policyHolder2);
//        policyHolders.add(policyHolder3);
//        PolicyHoldersManagement policyHoldersManagement = new PolicyHoldersManagement(policyHolders);
//        System.out.println(policyHoldersManagement);

//        CardHolder cardHolder1 = new CardHolder(5,"dat");
//        CardHoldersManagement cardHoldersManagement = new CardHoldersManagement(cardholders);
//        cardHoldersManagement.addCustomer(cardHolder1);
//        cardHoldersManagement.addCustomer(cardHolder1);
//        System.out.println(cardHoldersManagement);

//        InsuranceCard insuranceCard = new InsuranceCard(12121);
//        InsuranceCardsManagement insuranceCardsManagement = new InsuranceCardsManagement(insuranceCards);
//        insuranceCardsManagement.addInsuranceCard(insuranceCard);
//        System.out.println(insuranceCard.toString());

        ClaimProcessManager claimProcessManager = new ClaimProcessManager();
    }
}